package com.reza.s3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author Reza Arshad
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.reza")
public class AmazonS3RestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazonS3RestApplication.class, args);
	}
}
