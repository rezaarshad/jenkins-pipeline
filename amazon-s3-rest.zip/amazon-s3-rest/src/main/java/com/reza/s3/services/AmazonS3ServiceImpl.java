package com.reza.s3.services;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import com.reza.s3.models.SampleS3;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;

@Service
public class AmazonS3ServiceImpl implements AmazonS3Service<SampleS3> {


    @Autowired
    private AmazonS3 amazonS3Client;

    @Override
    public @NotNull Iterable<SampleS3> findByQuery(String query) {
        SelectObjectContentRequest request = generateBaseCSVRequest("srp-test2", "f1.txt", "select s._1 from S3Object s");

        SelectObjectContentResult result = amazonS3Client.selectObjectContent(request);
        return null;
    }

    @Override
    public SampleS3 get(Long id) {


        return null;
    }


    private static SelectObjectContentRequest generateBaseCSVRequest(String bucket, String key, String query) {
        SelectObjectContentRequest request = new SelectObjectContentRequest();
        request.setBucketName(bucket);
        request.setKey(key);
        request.setExpression(query);
        request.setExpressionType(ExpressionType.SQL);

        InputSerialization inputSerialization = new InputSerialization();
        inputSerialization.setCsv(new CSVInput());
        inputSerialization.setCompressionType(CompressionType.NONE);
        request.setInputSerialization(inputSerialization);

        OutputSerialization outputSerialization = new OutputSerialization();
        outputSerialization.setJson(new JSONOutput());
        request.setOutputSerialization(outputSerialization);

        return request;
    }

}
