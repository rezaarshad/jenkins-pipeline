package com.reza.s3.services;

import javax.validation.constraints.NotNull;

/**
 * @author Reza Arshad
 */
public interface AmazonS3Service<T> {

    @NotNull Iterable<T> findByQuery(String query);

    T get(Long id);

}
