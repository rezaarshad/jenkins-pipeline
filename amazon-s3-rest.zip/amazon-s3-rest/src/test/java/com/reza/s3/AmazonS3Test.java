package com.reza.s3;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import com.reza.s3.services.AmazonS3Service;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AmazonS3ApplicationTests.class)
public class AmazonS3Test {

    private String bucketName= "srp-test2";
    private String prefix= "test";
    private String key= "";

    @Autowired
    private AmazonS3 amazonS3;

    @Test
    public void testSelectObjectContent() {


        ListObjectsV2Request listObjectsRequest=new ListObjectsV2Request();
        listObjectsRequest.withBucketName(bucketName).withPrefix(prefix);

        ListObjectsV2Result listObjectsV2Result =  amazonS3.listObjectsV2(listObjectsRequest);


        SelectObjectContentRequest request = generateBaseCSVRequest(bucketName, "f1.txt", "select s._1 from S3Object s");

        SelectObjectContentResult result = amazonS3.selectObjectContent(request);
    }

    private static SelectObjectContentRequest generateBaseCSVRequest(String bucket, String key, String query) {
        SelectObjectContentRequest request = new SelectObjectContentRequest();
        request.setBucketName(bucket);
        request.setKey(key);
        request.setExpression(query);
        request.setExpressionType(ExpressionType.SQL);

        InputSerialization inputSerialization = new InputSerialization();
        inputSerialization.setCsv(new CSVInput());
        inputSerialization.setCompressionType(CompressionType.NONE);
        request.setInputSerialization(inputSerialization);

        OutputSerialization outputSerialization = new OutputSerialization();
        outputSerialization.setJson(new JSONOutput());
        request.setOutputSerialization(outputSerialization);

        return request;
    }

}
